// Compare two string
int strComp(char *str1, char *str2);

int startsWith(char *full, char *prefix);

int is_all_digits(const char *str);

int my_atoi(const char *str);
void strCopy(char *dest, const char *src);
int strLen(const char *str);