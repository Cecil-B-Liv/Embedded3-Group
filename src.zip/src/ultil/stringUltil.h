// Compare two string
int strComp(char *str1, char* str2);
int startsWith(char* full, char* prefix);