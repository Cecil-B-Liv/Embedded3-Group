void cli_welcome();
void cli_process();
void clearBuff(int isTab);
void clearDisplay();